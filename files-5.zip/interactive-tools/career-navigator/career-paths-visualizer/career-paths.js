/**
 * Career Paths Visualizer
 * This script visualizes career progression paths in the iGaming industry
 */

class CareerPathVisualizer {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.svg = null;
    this.data = null;
    this.width = this.container.clientWidth;
    this.height = 600;
    this.margin = {top: 50, right: 50, bottom: 50, left: 50};
    this.init();
  }

  async init() {
    // Initialize the SVG
    this.svg = d3.select(this.container)
      .append('svg')
      .attr('width', this.width)
      .attr('height', this.height)
      .append('g')
      .attr('transform', `translate(${this.margin.left}, ${this.margin.top})`);
    
    // Load data
    try {
      this.data = await this.loadData();
      this.renderChart();
    } catch (error) {
      this.showError('Failed to load career path data.');
      console.error(error);
    }
  }

  async loadData() {
    // In a real implementation, this would fetch from WordPress API
    // For example: const response = await fetch('/wp-json/wp/v2/career_paths');
    
    // For demo purposes, we'll use sample data
    return [
      {
        id: 1,
        title: 'Technology Career Path',
        start_position: 'Junior Developer',
        end_position: 'CTO',
        steps: [
          {level: 1, position: 'Junior Developer', years: '0-2', skills: ['HTML', 'CSS', 'JavaScript']},
          {level: 2, position: 'Developer', years: '2-4', skills: ['Backend', 'APIs', 'Databases']},
          {level: 3, position: 'Senior Developer', years: '4-6', skills: ['Architecture', 'Team Lead']},
          {level: 4, position: 'Tech Lead', years: '6-8', skills: ['Project Management', 'System Design']},
          {level: 5, position: 'Engineering Manager', years: '8-10', skills: ['People Management', 'Strategy']},
          {level: 6, position: 'Head of Development', years: '10-12', skills: ['Department Management']},
          {level: 7, position: 'VP of Engineering', years: '12-15', skills: ['Executive Leadership']},
          {level: 8, position: 'CTO', years: '15+', skills: ['Company Strategy', 'Board Relations']}
        ]
      },
      {
        id: 2,
        title: 'Marketing Career Path',
        start_position: 'Marketing Assistant',
        end_position: 'CMO',
        steps: [
          {level: 1, position: 'Marketing Assistant', years: '0-2'},
          {level: 2, position: 'Marketing Specialist', years: '2-4'},
          {level: 3, position: 'Senior Marketing Specialist', years: '4-6'},
          {level: 4, position: 'Marketing Manager', years: '6-8'},
          {level: 5, position: 'Senior Marketing Manager', years: '8-10'},
          {level: 6, position: 'Head of Marketing', years: '10-12'},
          {level: 7, position: 'VP of Marketing', years: '12-15'},
          {level: 8, position: 'CMO', years: '15+'}
        ]
      }
    ];
  }

  renderChart() {
    if (!this.data || this.data.length === 0) return;

    const innerWidth = this.width - this.margin.left - this.margin.right;
    const innerHeight = this.height - this.margin.top - this.margin.bottom;
    
    // Create path selection UI
    this.createPathSelector();
    
    // Display the first path by default
    this.displayPath(this.data[0]);
  }

  createPathSelector() {
    const selector = document.createElement('div');
    selector.className = 'path-selector';
    
    const label = document.createElement('label');
    label.textContent = 'Select Career Path: ';
    selector.appendChild(label);
    
    const select = document.createElement('select');
    this.data.forEach(path => {
      const option = document.createElement('option');
      option.value = path.id;
      option.textContent = path.title;
      select.appendChild(option);
    });
    
    select.addEventListener('change', (event) => {
      const selectedPath = this.data.find(path => path.id == event.target.value);
      if (selectedPath) this.displayPath(selectedPath);
    });
    
    selector.appendChild(select);
    this.container.insertBefore(selector, this.container.firstChild);
  }

  displayPath(pathData) {
    this.svg.selectAll('*').remove();
    
    const innerWidth = this.width - this.margin.left - this.margin.right;
    const innerHeight = this.height - this.margin.top - this.margin.bottom;
    
    // Set up scales
    const xScale = d3.scaleLinear()
      .domain([0, pathData.steps.length - 1])
      .range([0, innerWidth]);
    
    // Create the path line
    const line = d3.line()
      .x((d, i) => xScale(i))
      .y(innerHeight / 2)
      .curve(d3.curveLinear);
    
    // Add the path line
    this.svg.append('path')
      .datum(pathData.steps)
      .attr('fill', 'none')
      .attr('stroke', '#0066cc')
      .attr('stroke-width', 3)
      .attr('d', line);
    
    // Add position nodes
    const nodes = this.svg.selectAll('.position-node')
      .data(pathData.steps)
      .enter()
      .append('g')
      .attr('class', 'position-node')
      .attr('transform', (d, i) => `translate(${xScale(i)}, ${innerHeight / 2})`);
    
    // Add circles for each position
    nodes.append('circle')
      .attr('r', 12)
      .attr('fill', '#0066cc');
    
    // Add position labels
    nodes.append('text')
      .attr('y', 30)
      .attr('text-anchor', 'middle')
      .attr('font-weight', 'bold')
      .text(d => d.position);
    
    // Add year labels
    nodes.append('text')
      .attr('y', 50)
      .attr('text-anchor', 'middle')
      .attr('fill', '#666')
      .text(d => d.years + ' years');
    
    // Add path title
    this.svg.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', -20)
      .attr('text-anchor', 'middle')
      .attr('font-size', '20px')
      .attr('font-weight', 'bold')
      .text(pathData.title);
  }

  showError(message) {
    this.container.innerHTML = `<div class="error-message">${message}</div>`;
  }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
  const careerPathContainer = document.getElementById('career-path-container');
  if (careerPathContainer) {
    new CareerPathVisualizer('career-path-container');
  }
});